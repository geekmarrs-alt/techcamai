from __future__ import annotations

import base64
import os
import random
import time
from typing import List

import httpx
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    API_BASE_URL: str = "http://127.0.0.1:8000"
    POLL_INTERVAL_SEC: int = 30
    CAMERA_SNAPSHOT_URLS: str = ""  # legacy comma-separated


S = Settings()


def parse_urls(raw: str) -> List[str]:
    urls = [u.strip() for u in (raw or "").split(",")]
    return [u for u in urls if u]


def fetch_snapshot(url: str, auth: httpx.Auth | None = None, verify: bool = False) -> str | None:
    # returns base64 jpeg
    try:
        with httpx.Client(timeout=10.0, follow_redirects=True, verify=verify) as c:
            r = c.get(url, auth=auth)
            r.raise_for_status()
            content_type = r.headers.get("content-type", "")
            if "image" not in content_type and not r.content.startswith(b"\xff\xd8"):
                return None
            return base64.b64encode(r.content).decode("ascii")
    except Exception:
        return None


def fake_detect() -> tuple[str, float]:
    # MVP stub: random label/conf. Replace with YOLO/etc.
    label = random.choice(["person", "vehicle"])
    conf = random.uniform(0.3, 0.99)
    return label, conf


def post_detection(snapshot_url: str, label: str, conf: float, snapshot_b64: str | None):
    payload = {
        "camera_snapshot_url": snapshot_url,
        "label": label,
        "conf": conf,
        "snapshot_b64": snapshot_b64,
    }
    with httpx.Client(timeout=10.0) as c:
        r = c.post(f"{S.API_BASE_URL}/ingest/detection", json=payload)
        r.raise_for_status()
        return r.json()


def _camera_snapshot_url(cam: dict) -> str:
    ip = cam.get("ip")
    scheme = cam.get("scheme") or "https"
    channel = int(cam.get("channel") or 1)
    # Prefer ISAPI first, but we can add fallbacks later
    return f"{scheme}://{ip}/ISAPI/Streaming/channels/{channel}/picture"


def _camera_auth(cam: dict) -> httpx.Auth | None:
    user = cam.get("username")
    pw = cam.get("password")
    if not user or not pw:
        return None
    auth = (cam.get("auth") or "digest").lower()
    if auth == "basic":
        return httpx.BasicAuth(user, pw)
    return httpx.DigestAuth(user, pw)


def get_cameras() -> list[dict]:
    # MVP: local worker endpoint returns creds
    with httpx.Client(timeout=5.0) as c:
        r = c.get(f"{S.API_BASE_URL}/worker/cameras")
        r.raise_for_status()
        return r.json()


def main():
    while True:
        try:
            cams = get_cameras()
        except Exception as e:
            print(f"[worker] Could not fetch cameras: {e}")
            cams = []

        # legacy env fallback
        urls = parse_urls(S.CAMERA_SNAPSHOT_URLS)
        legacy = [{"ip": None, "snapshot_url": u} for u in urls]

        if not cams and not legacy:
            print("[worker] No cameras configured yet.")

        for cam in cams:
            url = _camera_snapshot_url(cam)
            auth = _camera_auth(cam)
            snap_b64 = fetch_snapshot(url, auth=auth, verify=False)
            label, conf = fake_detect()
            try:
                res = post_detection(url, label, conf, snap_b64)
                trig = res.get("triggered", [])
                if trig:
                    print(f"[worker] Triggered {len(trig)} alert(s) for {cam.get('ip')} label={label} conf={conf:.2f}")
            except Exception as e:
                print(f"[worker] Error posting detection for {cam.get('ip')}: {e}")

        # legacy URLs
        for l in legacy:
            u = l["snapshot_url"]
            snap_b64 = fetch_snapshot(u)
            label, conf = fake_detect()
            try:
                res = post_detection(u, label, conf, snap_b64)
                trig = res.get("triggered", [])
                if trig:
                    print(f"[worker] Triggered {len(trig)} alert(s) for {u} label={label} conf={conf:.2f}")
            except Exception as e:
                print(f"[worker] Error posting detection for {u}: {e}")

        time.sleep(max(1, int(S.POLL_INTERVAL_SEC)))


if __name__ == "__main__":
    main()
